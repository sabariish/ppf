import React from 'react';
import PropTypes from 'prop-types';
import Typography from '@material-ui/core/Typography';
import MediaCard from '../components/MediaCard/MediaCard'
//import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
//import grey from '@material-ui/core/colors/grey';
import { withStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import InputBase from '@material-ui/core/InputBase';
import Accessibility from '@material-ui/icons/Accessibility';
import Grid from '@material-ui/core/Grid';
import SimpleCard from '../components/SimpleCard/SimpleCard';

const styles = theme => ({
    root: {
        flexGrow: 1,
    },
    background: {
        backgroundColor: "red"
      }
})



function KnowledgeCentre(props) {
    const { classes } = props;
    return(
    <div classname={classes.root}>
        
    
    <div style={{backgroundColor:'#c8e6c9',background: "linear-gradient(45deg, #c8e6c9, #e8f5e9)"}}>
    
      <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom style={{padding:"20px", "fontFamily": "Roboto","fontSize": 30}}>
        Knowledge Centre
      </Typography>
      
      <SearchIcon style={{"background-color": "white",
    color:"blue", height:"60px"}}/>
                            
                            <InputBase
                                placeholder="What are you looking for?"
                                style={{"background-color": "white", width:"50%" , height:"60px", padding:"20px" }}
                            />
                            <br/>
                            <br/>
                            <br/>
                            <br/>


    </div>
   <div>
      
       <Grid container spacing={12} style={{"margin": "25px 50px"}}>
       <Grid item xs>
   <MediaCard header="Web API Design" description='Use the ApiGrid v3 REST API to build and send email.' imagePath = {'homeIcon'} />
   </Grid>
   <Grid item xs>
   <MediaCard header="Scaling Microservices" description='Use the ApiGrid v3 REST API to build and send email.' imagePath = {'srvcIcon'}/>
   </Grid>
   <Grid item xs>
   <MediaCard header="API Mindset" description='Use the ApiGrid v3 REST API to build and send email.' imagePath = {'apiIcon'}/>
   </Grid>
</Grid>
</div>
   <div >
   <br/>
    <Typography component="h5">Featured Resources</Typography>
    <Grid container spacing={12}>
    <Grid item xs>
    <SimpleCard/>
    </Grid>
    <Grid item xs>
    <SimpleCard/>
    </Grid>
</Grid>
   </div>

  </div>);

}
KnowledgeCentre.propTypes = {
    classes: PropTypes.object.isRequired,
};
export default withStyles(styles) (KnowledgeCentre);