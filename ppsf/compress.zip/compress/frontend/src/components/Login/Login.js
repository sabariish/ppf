import React, {Component} from 'react';
import Header from '../Header/Header'
import KnowledgeCentre from '../../views/KnowledgeCentre';

class Login extends Component {
    render(){
        return(
        <div>
            <Header header="CineArt"/>
           <KnowledgeCentre/>
        </div>
      );
    }
}
export default Login;