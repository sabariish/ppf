import React from 'react';
import './header.css';
import AppBar from '../AppBar/AppBar';

const Header = (props) => {
return( 
  <div>
  <AppBar/>

  </div>
      );
}

export default Header;
