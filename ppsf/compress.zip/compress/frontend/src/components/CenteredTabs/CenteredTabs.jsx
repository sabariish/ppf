import React from 'react';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import { Link as RouterLink } from 'react-router-dom'
import Link from '@material-ui/core/Link';

class CenteredTabs extends React.Component {
    state = {
        value: 0,
      };
    
      handleChange = (event, value) => {
        this.setState({ value });
      };
    
      render() {
        
    
        return (
          <div>
          
            <Tabs
              value={this.state.value}
              onChange={this.handleChange}
              indicatorColor="primary"
              textColor="inherit"
              centered
            >
              <Tab label="Knowledge Centre" />
              <Tab label="Contact Support" />
              <Tab label="For Developers" />
              <Tab label="Status" />

            </Tabs>
            </div>
        );
      }
}
export default CenteredTabs;