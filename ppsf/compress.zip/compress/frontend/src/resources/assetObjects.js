const assetsObject = {
  homeIcon: require('../components/MediaCard/apidesign.png'),
  srvcIcon: require('../components/MediaCard/maximizing-microservices.png'),
  apiIcon: require('../components/MediaCard/api.png')
  
}
module.exports = assetsObject