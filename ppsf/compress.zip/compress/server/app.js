const createError = require('http-errors')
const express = require('express')
const path = require('path')
const cookieParser = require('cookie-parser')
const logger = require('morgan')
const bodyParser = require('body-parser')

const apiNameRouter = require('./routes/getProperties/index')

const app = express()

// VIEW ENGINE SETUP
app.set('view', path.join(__dirname, 'views'))
app.set('view engine', 'jade')

//additional config
app.use(logger('dev'))
app.use(bodyParser.json({limit: '50mb'}))
app.use(bodyParser.urlencoded({limit:   '50mb', extended:   true, parameterLimit:   50000}))
app.use(cookieParser())
app.use(express.static(path.join(__dirname, 'public')))

app.use('/api/toroute', apiNameRouter)

// catch 404 and forward to error handler
app.use(function(err, req, res, next){
    res.locals.message = err.message
    res.locals.error = req.app.get('env')==='development' ? err:{}

    res.status(err.status || 500)
    res.render (error)
})

module.exports = app