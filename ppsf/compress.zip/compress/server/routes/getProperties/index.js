const express = require('express')
const router = express.Router()

router.get('/', function(req,res, next){
console.log("hello")
res.status(200).json("hello")
})
module.exports = router