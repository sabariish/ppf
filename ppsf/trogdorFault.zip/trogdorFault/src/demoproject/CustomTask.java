package demoproject;

import org.apache.kafka.common.utils.Exit;
import org.apache.kafka.trogdor.common.JsonUtil;
import org.apache.kafka.trogdor.coordinator.CoordinatorClient;
import org.apache.kafka.trogdor.coordinator.CoordinatorClient.Builder;
import org.apache.kafka.trogdor.rest.CreateTaskRequest;
import org.apache.kafka.trogdor.rest.RequestConflictException;
import org.apache.kafka.trogdor.task.TaskSpec;

import com.qmetry.qaf.automation.core.ConfigurationManager;

public class CustomTask {

	// TODO Auto-generated method stub
	private String target = ConfigurationManager.getBundle().getString("coordinator");
	private String taskId = "task0";
	private String taskSpecPath = ConfigurationManager.getBundle().getString("produceTask");;

	public CustomTask() {
	};

	public CustomTask(String target, String taskId, String taskSpecPath) {
		this.target = target;
		this.taskId = taskId;
		this.taskSpecPath = taskSpecPath;
	}

	public void createCustomTask() {
		CoordinatorClient client = new Builder().maxTries(3).target(target).build();

		TaskSpec taskSpec = null;

		try {
			taskSpec = JsonUtil.objectFromCommandLineArgument(taskSpecPath, TaskSpec.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CreateTaskRequest req = new CreateTaskRequest(taskId, taskSpec);
		try {
			try {
				client.createTask(req);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.printf("Sent CreateTaskRequest for task %s.%n", req.id());
		} catch (RequestConflictException rce) {
			System.out.printf(
					"CreateTaskRequest for task %s got a 409 status code - "
							+ "a task with the same ID but a different specification already exists.%nException: %s%n",
					req.id(), rce.getMessage());
			Exit.exit(1);
		}

	}

}
