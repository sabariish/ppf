package demoproject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qmetry.qaf.automation.core.ConfigurationManager;

import java.util.concurrent.ThreadLocalRandom;

import org.apache.kafka.common.utils.Scheduler;
import org.apache.kafka.trogdor.common.Node;
import org.apache.kafka.trogdor.common.Platform;
import org.apache.kafka.trogdor.coordinator.Coordinator;
import org.apache.kafka.trogdor.coordinator.CoordinatorRestResource;
import org.apache.kafka.trogdor.rest.JsonRestServer;

public class CustomCoordinator {
	private static final Logger log = LoggerFactory.getLogger(CustomCoordinator.class);

	private String configPath = ConfigurationManager.getBundle().getString("configPath");
	private String nodeName = ConfigurationManager.getBundle().getString("nodeName");

	public CustomCoordinator() {
	};

	public CustomCoordinator(String configPath, String nodeName) {
		this.configPath = configPath;
		this.nodeName = nodeName;
	}

	public void startCoordinator() {
		Platform platform = null;
		try {
			platform = Platform.Config.parse(nodeName, configPath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JsonRestServer restServer = new JsonRestServer(Node.Util.getTrogdorCoordinatorPort(platform.curNode()));
		CoordinatorRestResource resource = new CoordinatorRestResource();
		log.info("Starting coordinator process.");
		final Coordinator coordinator = new Coordinator(platform, Scheduler.SYSTEM, restServer, resource,
				ThreadLocalRandom.current().nextLong(0, Long.MAX_VALUE / 2));
		restServer.start(resource);
		System.out.printf("Started Coordinator on port: %s",String.valueOf(coordinator.port()));
	}
}
