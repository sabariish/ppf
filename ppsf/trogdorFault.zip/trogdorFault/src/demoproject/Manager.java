package demoproject;

import com.qmetry.qaf.automation.core.ConfigurationManager;

public class Manager {
	static void startAgentCoord() {
		String configPath = ConfigurationManager.getBundle().getString("configPath");
		String nodeName = ConfigurationManager.getBundle().getString("nodeName");
		CustomAgent agent = new CustomAgent(configPath,nodeName,"");
		agent.startAgent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		CustomCoordinator coordinator = new CustomCoordinator(configPath,nodeName);
		coordinator.startCoordinator();
	}

	static void startTask(String target, String taskId, String taskSpecPath) {
		CustomTask task = new CustomTask(target, taskId, taskSpecPath);
		task.createCustomTask();
	}

	static void useCase1() {
		startAgentCoord();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		String target = ConfigurationManager.getBundle().getString("coordinator");
		String taskId = "produceTask";
		String taskSpecPath = ConfigurationManager.getBundle().getString("taskSpec");;
		startTask(target, taskId, taskSpecPath);
		System.out.println("Started Task.....");
				
	}

	public static void main(String[] args) {
		useCase1();
//		startAgentCoord();
	}

}
