This projects runs processFault and netwrokpartitisn fault as per configurations file providied in properties file.

Attached sample processStop.json and network_fault.json.

Run project with changing appropriate taskspec in properties file.
