package com.shravya.kafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.shravya.kafka.constants.IKafkaConstants;
import com.shravya.kafka.producer.ProducerCreator;

public class KafkaProducer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Producer<Long, String> producer = ProducerCreator.createProducer();
		StringBuffer buffer = new StringBuffer();
		try {
			File file = new File ("\\Users\\shravyabussari\\Desktop\\TestFile.txt");
			BufferedReader bufferReader = new BufferedReader(new FileReader(file));
			String readLine= "";
			while((readLine = bufferReader.readLine())!=null) 
					{
				buffer.append(readLine).append("/n");
					}
		}
				catch(IOException e) {
					e.printStackTrace();
				}
					
		

			final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(IKafkaConstants.TOPIC_NAME,
					buffer.toString());
			try {
				RecordMetadata metadata = producer.send(record).get();
				
			} catch (ExecutionException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			} catch (InterruptedException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			}
		}
	

	

}
