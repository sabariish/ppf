package com.shravya.kafka;

import java.util.Collections;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.shravya.kafka.constants.IKafkaConstants;
import com.shravya.kafka.producer.ProducerCreator;

public class KafkaProducer {

	public static void producer(String taskType) {
		// TODO Auto-generated method stub

		Producer<Long, String> producer = ProducerCreator.createProducer();
		String topicName = null;

		if(taskType.equals("network")) {
			topicName =IKafkaConstants.TOPIC_NAME_NETWORKFAULT;;
			}else {
				System.out.println("topic in producer:"+IKafkaConstants.TOPIC_NAME_PROCESSSTOP);
				
				topicName =IKafkaConstants.TOPIC_NAME_PROCESSSTOP;
					
			}
		System.out.println("topin in producer1:"+topicName);
		for (int index = 0; index < IKafkaConstants.MESSAGE_COUNT; index++) {
			
			final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(topicName,
					"This is record " + index);
			try {
				System.out.println("before message sent:");
				
				RecordMetadata metadata = producer.send(record).get();
				System.out.println("message sent:");
			} catch (ExecutionException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			} catch (InterruptedException e) {
				System.out.println("Error in sending record");
				System.out.println(e);
			}
		}
	

	}

}
