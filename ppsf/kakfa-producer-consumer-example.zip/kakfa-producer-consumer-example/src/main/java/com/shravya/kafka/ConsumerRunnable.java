package com.shravya.kafka;

public class ConsumerRunnable implements Runnable {
	public String taskType= null;

	public ConsumerRunnable(String taskType) {
		this.taskType = taskType;
		
	}
	public void run() {
		KafkaConsumer consumer = new KafkaConsumer();
		consumer.callConsumer(taskType);
	}
	public static void init(String taskType) {
		// TODO Auto-generated method stub
     ConsumerRunnable runner = new ConsumerRunnable(taskType);
     Thread thread = new Thread(runner);
     thread.start();
	}

}
