package com.shravya.app;

import com.shravya.kafka.trogdor.CustomAgent;
import com.shravya.kafka.trogdor.Manager;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Tragdor
		//Manager.main(null);
	    
	}

}
