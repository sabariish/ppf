package com.shravya.app;


import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

public class Test {

	
	    public static void main(String[] args) throws Exception {
	    	//File file = new File("/Users/shravyabussari/Desktop/Tools/Kafka/bin/zookeeper-server-start.sh");
	    	
	    	//./bin/zookeeper-server-start.sh ./config/zookeeper.properties &> /tmp/zookeeper.log &

	    	//Process p = Runtime.getRuntime().exec("/Users/shravyabussari/Desktop/Tools/Kafka/bin/zookeeper.sh");
	   
		    	ProcessBuilder pb = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/zookeeper-server-start.sh","/Users/shravyabussari/Desktop/Tools/Kafka/config/zookeeper.properties");
	    	Process p = pb.start();
	    	 BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
	    	 String line = null;
	    	 while ((line = reader.readLine()) != null)
	    	 {
	    	    System.out.println(line);
	    	    if(line.contains("checkIntervalMs=60000 maxPerMinute=10000")) {
	    	    	 System.out.print("completed zookeeper");
	    		    break;	
	    	    	 
	    	    }
	    	 }  
	    	 
	    	 
	      
	    }
}