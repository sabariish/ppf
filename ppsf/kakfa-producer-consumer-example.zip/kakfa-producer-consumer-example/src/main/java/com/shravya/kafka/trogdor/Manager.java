package com.shravya.kafka.trogdor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.qmetry.qaf.automation.core.ConfigurationManager;

public class Manager {
	
	static void startAgentCoord() {
		String configPath = ConfigurationManager.getBundle().getString("configPath");
		String nodeName = ConfigurationManager.getBundle().getString("nodeName");
		CustomAgent agent = new CustomAgent(configPath,nodeName,"");
		agent.startAgent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		CustomCoordinator coordinator = new CustomCoordinator(configPath,nodeName);
		coordinator.startCoordinator();
	}

	static void startTask(String target, String taskId, String taskSpecPath) {
		CustomTask task = new CustomTask(target, taskId, taskSpecPath);
		task.createCustomTask();
	}

	static void useCase1() {
		startAgentCoord();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		String target = ConfigurationManager.getBundle().getString("coordinator");
		String taskId = "trogdorFaultTask";
		String taskSpecPath = ConfigurationManager.getBundle().getString("taskSpec");;
		startTask(target, taskId, taskSpecPath);
		System.out.println("Started Task.....");
				
				}

	public static void main(String[] args) {
		boolean zookeeperStarted = false;
		boolean kafkaStarted = false;
		 
		try {
			ProcessBuilder pb = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/zookeeper-server-start.sh","/Users/shravyabussari/Desktop/Tools/Kafka/config/zookeeper.properties");
	    	Process p = pb.start();
	    	 BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
	    	 String line = null;
	    	 while ((line = reader.readLine()) != null)
	    	 {
	    	    System.out.println(line);
	    	    if(line.contains("checkIntervalMs=60000 maxPerMinute=10000")) {
	    	    	zookeeperStarted = true;
	    	    	 System.out.print("completed zookeeper");
	    		    break;	
	    	    	 
	    	    }
	    	 }  
	    	 if(zookeeperStarted) {
	    		 
	    		 ProcessBuilder pb1 = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/kafka-server-start.sh","/Users/shravyabussari/Desktop/Tools/Kafka/config/server.properties");
	 	    	Process p1 = pb1.start();
	 	    	 BufferedReader kafkaBuffer = new BufferedReader(new InputStreamReader(p1.getInputStream()));
	 	    	 String ln = null;
	 	    	 while ((ln = kafkaBuffer.readLine()) != null)
	 	    	 {
	 	    		
	 	    	    System.out.println(ln);
	 	    	    if(ln.contains("started (kafka.server.KafkaServer)")) {
	 	    	    	kafkaStarted = true;
	 	    	    	 System.out.print("completed kafka");
	 	    		    break;	
	 	    	    	 
	 	    	    }
	 	    	 }  
	 	    	
	    	 }
	    	 
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  
    	 
    	 if(zookeeperStarted && kafkaStarted) {
    		 useCase1();
    		 
    	 }
		
//		startAgentCoord();
	}

}
