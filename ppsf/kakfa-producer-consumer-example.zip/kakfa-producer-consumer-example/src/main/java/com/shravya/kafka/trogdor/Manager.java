package com.shravya.kafka.trogdor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.junit.Test;

import com.qmetry.qaf.automation.core.ConfigurationManager;

public class Manager {
	CustomAgent agent = null;
	
	 void startAgentCoord() {
		String configPath = ConfigurationManager.getBundle().getString("configPath");
		String nodeName = ConfigurationManager.getBundle().getString("nodeName");
		 agent = new CustomAgent(configPath,nodeName,"");
		agent.startAgent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		CustomCoordinator coordinator = new CustomCoordinator(configPath,nodeName);
		coordinator.startCoordinator();
	}

	static void startTask(String target, String taskId, String taskSpecPath) {
		CustomTask task = new CustomTask(target, taskId, taskSpecPath);
		if(taskSpecPath.contains("network")) {
			task.createCustomTask("network");
		}else {
		task.createCustomTask("process");
		}
	}

	 void useCase1(String taskSpecPath) {
		startAgentCoord();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		String target = ConfigurationManager.getBundle().getString("coordinator");
		String taskId = "trogdorFaultTask";
		//String taskSpecPath = ConfigurationManager.getBundle().getString("taskSpec");;
		startTask(target, taskId, taskSpecPath);
		System.out.println("Task completed..");
				
				}
	@Test
	public void testProcessFault() throws Exception {
Manager manager = new Manager();
manager.startServers("processStop.json");
	}
	
	
	@Test
	public void testNetworkFault() throws Exception {
Manager manager = new Manager();
manager.startServers("networkPartitionFault.json");
	}


	public void startServers(String taskSpecPath) throws InterruptedException {
		boolean zookeeperStarted = false;
		boolean kafkaStarted = false;
		if(agent !=null) {
	       agent.stopAgent();
		}
		 
		try {
			ProcessBuilder kafkaStop = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/kafka-server-stop.sh");
	    	kafkaStop.start();
	    	Thread.sleep(3000);
	    	ProcessBuilder zookeeperStop = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/zookeeper-server-stop.sh");
	    	zookeeperStop.start();
	    	Thread.sleep(3000);
			
			ProcessBuilder pb = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/zookeeper-server-start.sh","/Users/shravyabussari/Desktop/Tools/Kafka/config/zookeeper.properties");
	    	Process p = pb.start();
	    	 BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
	    	 String line = null;
	    	 while ((line = reader.readLine()) != null)
	    	 {
	    	    System.out.println(line);
	    	    if(line.contains("checkIntervalMs=60000 maxPerMinute=10000")) {
	    	    	zookeeperStarted = true;
	    	    	 System.out.print("completed zookeeper");
	    		    break;	
	    	    	 
	    	    }
	    	 }  
	    	 if(zookeeperStarted) {
	    		 
	    		 ProcessBuilder pb1 = new ProcessBuilder("/Users/shravyabussari/Desktop/Tools/Kafka/bin/kafka-server-start.sh","/Users/shravyabussari/Desktop/Tools/Kafka/config/server.properties");
	 	    	Process p1 = pb1.start();
	 	    	 BufferedReader kafkaBuffer = new BufferedReader(new InputStreamReader(p1.getInputStream()));
	 	    	 String ln = null;
	 	    	 while ((ln = kafkaBuffer.readLine()) != null)
	 	    	 {
	 	    		
	 	    	    System.out.println(ln);
	 	    	    if(ln.contains("started (kafka.server.KafkaServer)")) {
	 	    	    	kafkaStarted = true;
	 	    	    	 System.out.print("completed kafka");
	 	    		    break;	
	 	    	    	 
	 	    	    }
	 	    	 }  
	 	    	
	    	 }
	    	 
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  
   	 
    	if(zookeeperStarted && kafkaStarted) {
    		 useCase1(taskSpecPath);
    		 
    	 }
		
		
	}

}
