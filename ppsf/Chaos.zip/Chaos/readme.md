Prerequisites:
- For First use case you need to have kafka cluster running.
- For second use case you need to have kafka running on remote machine(we have simlulated this scenario)

Setup:
- To setup kafka on linux remote machine - https://linuxhint.com/install-apache-kafka-ubuntu/
- Change environment parameters in project according to your system.

Put server-x.properties and trogdor.conf file in config folder of kafka.
Put task jsonfiles in relevent folder. you need to provide path in project configurations.




