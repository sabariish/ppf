package com.shravya.kafka;

public class ConsumerRunnable implements Runnable {

	public void run() {
		//KafkaConsumer.main(null);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     ConsumerRunnable runner = new ConsumerRunnable();
     Thread thread = new Thread(runner);
     thread.start();
	}

}
