package com.shravya.kafka.trogdor;

import org.apache.kafka.common.utils.Scheduler;
import org.apache.kafka.trogdor.agent.Agent;
import org.apache.kafka.trogdor.agent.AgentRestResource;
import org.apache.kafka.trogdor.common.Node;
import org.apache.kafka.trogdor.common.Platform;
import org.apache.kafka.trogdor.rest.JsonRestServer;

import com.qmetry.qaf.automation.core.ConfigurationManager;
public class CustomAgent {
	// TODO Auto-generated method stub

	private String configPath = ConfigurationManager.getBundle().getString("configPath");
	private String nodeName = ConfigurationManager.getBundle().getString("nodeName");
	private String taskSpec = "";

	public CustomAgent() {
	};

	public CustomAgent(String configPath, String nodeName, String taskSpec) {
		this.configPath = configPath;
		this.nodeName = nodeName;
		this.taskSpec = taskSpec;
	}

	void startAgent() {
		Platform platform = null;
		try {
			platform = Platform.Config.parse(nodeName, configPath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonRestServer restServer = new JsonRestServer(Node.Util.getTrogdorAgentPort(platform.curNode()));
		AgentRestResource resource = new AgentRestResource();
		final Agent agent = new Agent(platform, Scheduler.SYSTEM, restServer, resource);
		restServer.start(resource);
		System.out.printf("Started Agent on port: %s",String.valueOf(agent.port()));
	}

}
