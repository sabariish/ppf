package com.shravya.kafka.trogdor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.aspectj.org.eclipse.jdt.internal.compiler.batch.Main;

import com.qmetry.qaf.automation.core.ConfigurationManager;

public class Manager {
	
	static void startAgentCoord(String path)  {
		//Properties prop = new Properties().load(inStream);
		String configPath = ConfigurationManager.getBundle().getString("configPath");
		configPath = "/config/trogdor.conf";
		String nodeName = ConfigurationManager.getBundle().getString("nodeName");
		nodeName ="node0";
		CustomAgent agent = new CustomAgent(path+configPath,nodeName,"");
		System.out.println("configPath:"+configPath);
		agent.startAgent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		CustomCoordinator coordinator = new CustomCoordinator(path+configPath,nodeName);
		coordinator.startCoordinator();
	}

	static void startTask(String target, String taskId, String taskSpecPath) {
		CustomTask task = new CustomTask(target, taskId, taskSpecPath);
		task.createCustomTask();
	}

	static void useCase1(String path) {
		startAgentCoord(path);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		String target = ConfigurationManager.getBundle().getString("coordinator");
		target = "localhost:8889";
		String taskId = "trogdorFaultTask";
		//String taskSpecPath = ConfigurationManager.getBundle().getString("taskSpec");;
		
		String taskSpecPath ="./processStop.json";
		System.out.println("task spec path:"+taskSpecPath);
		startTask(target, taskId, taskSpecPath);
		System.out.println("Started Task.....");
				
				}

	public static void main(String[] args) {
		boolean zookeeperStarted = false;
		boolean kafkaStarted = false;
		String path = args[0];
		System.out.println("path:"+path);
		 
		try {
			ProcessBuilder pb = new ProcessBuilder(path+"/bin/zookeeper-server-start.sh",path+"/config/zookeeper.properties");
	    	Process p = pb.start();
	    	 BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
	    	 String line = null;
	    	 while ((line = reader.readLine()) != null)
	    	 {
	    	    System.out.println(line);
	    	    if(line.contains("checkIntervalMs=60000 maxPerMinute=10000")) {
	    	    	zookeeperStarted = true;
	    	    	 System.out.print("completed zookeeper");
	    		    break;	
	    	    	 
	    	    }
	    	 }  
	    	 if(zookeeperStarted) {
	    		 
	    		 ProcessBuilder pb1 = new ProcessBuilder(path+"/bin/kafka-server-start.sh",path+"/config/server.properties");
	 	    	Process p1 = pb1.start();
	 	    	 BufferedReader kafkaBuffer = new BufferedReader(new InputStreamReader(p1.getInputStream()));
	 	    	 String ln = null;
	 	    	 while ((ln = kafkaBuffer.readLine()) != null)
	 	    	 {
	 	    		
	 	    	    System.out.println(ln);
	 	    	    if(ln.contains("started (kafka.server.KafkaServer)")) {
	 	    	    	kafkaStarted = true;
	 	    	    	 System.out.print("completed kafka");
	 	    		    break;	
	 	    	    	 
	 	    	    }
	 	    	 }  
	 	    	
	    	 }
	    	 
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  
    	 
    	 if(zookeeperStarted && kafkaStarted) {
    		 useCase1(path);
    		 
    	 }
		
//		startAgentCoord();
	}

}
