package com.shravya.kafka.trogdor;

import org.apache.kafka.common.utils.Exit;
import org.apache.kafka.trogdor.common.JsonUtil;
import org.apache.kafka.trogdor.coordinator.CoordinatorClient;
import org.apache.kafka.trogdor.coordinator.CoordinatorClient.Builder;
import org.apache.kafka.trogdor.rest.CreateTaskRequest;
import org.apache.kafka.trogdor.rest.RequestConflictException;
import org.apache.kafka.trogdor.rest.TaskRequest;
import org.apache.kafka.trogdor.rest.TaskState;
import org.apache.kafka.trogdor.rest.TaskStateType;
import org.apache.kafka.trogdor.task.TaskSpec;
import org.json.JSONObject;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.shravya.kafka.ConsumerRunnable;
import com.shravya.kafka.KafkaConsumer;
import com.shravya.kafka.KafkaProducer;

public class CustomTask {

	// TODO Auto-generated method stub
	private String target = ConfigurationManager.getBundle().getString("coordinator");
	private String taskId = "trogdorFaultTask";
	private String taskSpecPath = ConfigurationManager.getBundle().getString("trogdorFaultTask");;

	public CustomTask() {
	};

	public CustomTask(String target, String taskId, String taskSpecPath) {
		this.target = target;
		this.taskId = taskId;
		this.taskSpecPath = taskSpecPath;
	}

	public void createCustomTask() {
		CoordinatorClient client = new Builder().maxTries(3).target(target).build();

		TaskSpec taskSpec = null;

		try {
			taskSpecPath =" {\n" + 
					"    \"class\": \"org.apache.kafka.trogdor.fault.ProcessStopFaultSpec\",\n" + 
					"    \"startMs\": 1000,\n" + 
					"    \"durationMs\": 120000,\n" + 
					"    \"nodeNames\": \"node0\",\n" + 
					"    \"javaProcessName\": \"Kafka\"\n" + 
					"}";
			taskSpec = JsonUtil.objectFromCommandLineArgument(taskSpecPath, TaskSpec.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CreateTaskRequest req = new CreateTaskRequest(taskId, taskSpec);
		
		try {
			try {
				System.out.println("***** Before Creating Task ******");
				client.createTask(req);
				System.out.println("***** After Creating Task ******");
				TaskRequest taskReq = new TaskRequest(taskId);
				while(true) {
			  TaskState state =client.task(taskReq);
			  System.out.println("state of the task:"+state);
			  JSONObject obj = new JSONObject(state.toString());
			  String status = obj.getString("state");
			  System.out.println("***** Task Status:"+status);
			//  System.out.println("***** Task Status:"+state.status().get("state").asText());
				 
			  if(TaskStateType.RUNNING.name().equals(status)) {
				  System.out.println("calling producer");
				  KafkaProducer producer = new KafkaProducer();
				  producer.main();
				  KafkaConsumer consumer = new KafkaConsumer();
				  consumer.main();
				//  break;
			  }
				}
			  
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.printf("Sent CreateTaskRequest for task %s.%n", req.id());
		} catch (RequestConflictException rce) {
			System.out.printf(
					"CreateTaskRequest for task %s got a 409 status code - "
							+ "a task with the same ID but a different specification already exists.%nException: %s%n",
					req.id(), rce.getMessage());
			Exit.exit(1);
		}

	}

}
