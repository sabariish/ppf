package com.shravya.kafka;

import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.shravya.kafka.constants.IKafkaConstants;
import com.shravya.kafka.producer.ProducerCreator;

public class KafkaProducer {

	public  void main() {
		// TODO Auto-generated method stub
		
		System.out.println("in Kfak");

		Producer<Long, String> producer = ProducerCreator.createProducer();

		for (int index = 0; index < 100; index++) {
			final ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(IKafkaConstants.TOPIC_NAME,
					"This is record " + index);
			try {
				
			 producer.send(record);
			// producer.flush();
				System.out.println(record.value());
				
			
			}catch (Exception exp) {
				//System.out.println(exp.pr);
				System.out.println("exception in producer:"+exp.getMessage());
			}
		}
	

	}

}
